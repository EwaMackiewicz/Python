import socket
import sys
from Task import Task
import json
import pickle
import os


def ddefault(o):
    return o.__dict__

def taskListToString(list):
    str ="To do list: "
    for i in range(0, len(list)):
        str += list[i].printTask()
    return str

def priorityTaskListToString(list,priority):
    str ="List contains:"
    for i in range(0, len(list)):
        if list[i].priority == priority:
            str += list[i].printTask()
    return str

def removeTask(list,id):
    s ="Task has not been found."
    for i in range(0, len(list)):
        if str(list[i].id) == str(id):
            s = "Removed:" + list.pop(i).printTask()
            return s
    return s


def processMessage(message, list):
    messageTable = message.split(";")
    if messageTable[0] == "SHOW":
        c.sendall(taskListToString(list).encode())                                  #converting a list of task to string and than encoding the string and sending it to client
    if messageTable[0] == "ADD":
        newTask = Task(Task.id,messageTable[1], messageTable[2], messageTable[3])   #creating new task
        list+=[newTask]                                                             #adding a new task to the list
    if messageTable[0] =="SHOWP":
        c.send(priorityTaskListToString(list,messageTable[1]).encode())             #converting tasks with X priority from the list to string and than encoding the string and sending it to client
    if messageTable[0] == "REMOVE":
        c.sendall(removeTask(list,messageTable[1]).encode())                        #sending data that has been removed
    if messageTable[0] == "EXIT":
        s.close()
        print("Server Terminated.")
        sys.exit()



s = socket.socket()
host = socket.gethostname()
port = 12345
s.bind((host, port))
s.listen(5)



taskList = []
Task.id = 0
size = os.path.getsize("taskList.json")
if size > 0:
    with open("taskList.json", 'r') as txtfile:
        fromJson = json.load(txtfile)
        for i in range(0, len(fromJson)):
            taskList.append(Task.fromDict(fromJson[i]))
        Task.id = taskList[-1].id + 1

#Loop that keep accepting connections from Clients
while True:
    print("Waiting for incoming connections..")
    c, address = s.accept()     # Establish connection with client.
    receivedMessage = c.recv(1024).decode()
    print('Got connection from', address," Message was: ",receivedMessage)
    processMessage(receivedMessage,taskList)

    #write taskList to json
    fileObject = open("taskList.json", 'w')
    serlializedTaskList = json.dumps(taskList, default=ddefault)
    fileObject.write(serlializedTaskList)
    fileObject.close()


    c.close()

