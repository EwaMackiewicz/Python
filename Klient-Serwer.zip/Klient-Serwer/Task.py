

class Task:
    id = 0
    name = ""
    description =""
    priority = 0

    def __init__(self,id, name, description, priority):
        self.id = id
        self.name = name
        self.description = description
        self.priority = priority
        Task.id += 1

    def printTask(self):
        s = "\n\nTask Id: "+str(self.id)+" Priority: "+str(self.priority)+" Name: "+self.name+"\nDescription: "+ self.description
        return s


#used for initializing Task from a dictionary. Use: foo = Task.fromDict({"id":bar,"name": baz, etc.})
    @classmethod
    def fromDict(cls, dictionary):
        return cls(dictionary["id"], dictionary["name"], dictionary["description"], dictionary["priority"])